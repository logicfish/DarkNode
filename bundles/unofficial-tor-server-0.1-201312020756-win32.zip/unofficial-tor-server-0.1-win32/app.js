
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
  , path = require('path');

var app = express();

// all environments
app.set('port', process.env.PORT || 9080);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/users', user.list);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});

/*

*/

/**
 * To generate a self-signed SSL certificate (for https):
 * 
 * 
 * Install win32 openssl binary: 
 * https://www.openssl.org/related/binaries.html
 * 
 * openssl genrsa -out key.pem
 * openssl req -new -key key.pem -out csr.pem
 * openssl x509 -req -days 9999 -in csr.pem -signkey key.pem -out cert.pem
 * rm csr.pem
 * mv key.pem cert.pem ./Data/SSL
 * 
 */

/*

// HTTPS Server

var fs = require('fs')
  , https = require('https');

// This line is from the Node.js HTTPS documentation.
var options = {
  key: fs.readFileSync('./Data/SSL/key.pem').toString(),
  cert: fs.readFileSync('./Data/SSL/cert.pem').toString()
};

app.set('httpsport', process.env.HTTPSPORT || 9443);

https.createServer(options,app).listen(app.get('httpsport'), function(){
  console.log('Express https-server listening on port ' + app.get('httpsport'));
});

*/